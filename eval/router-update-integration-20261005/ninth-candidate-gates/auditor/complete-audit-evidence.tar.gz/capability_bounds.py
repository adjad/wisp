import sys,tempfile,json,copy
from pathlib import Path
from datetime import datetime,timezone,timedelta
from types import SimpleNamespace
ROOT=Path('/Users/adijain/.codex/worktrees/router-update-integration/MOE_Project');OUT=Path('/private/tmp/wisp-router-67e4cef-gates-20261005/auditor')
sys.path.insert(0,str(ROOT));from scripts import eval_router_update as e
SHA=e.git_revision();assert SHA=='67e4cefa53687f265287b9d068fc549c1f7955b6'
state=Path(tempfile.mkdtemp(prefix='wisp-67e4cef-bounds-'));e.install_guard(state,OUT)
rows=[]
def row(n,f,expected=True):
 try:a=f();rows.append(dict(id=n,actual=a,expected=expected,pass_=a==expected))
 except Exception as ex:rows.append(dict(id=n,pass_=False,error=type(ex).__name__))
def denied(f):
 try:f()
 except PermissionError:return True
 return False
grant=e.InferenceGrant('Ling-Independent','revision','f'*64,'synthetic-only',('127.0.0.1',8000),True)
cap=e.RuntimeCapability(grant,end_utc=(datetime.now(timezone.utc)+timedelta(hours=1)).isoformat(),execution_receipt='offline')
row('cap-default-disabled',lambda:denied(cap.check));cap.enabled=True
for field,value in [('enabled',False),('execution_receipt',''),('revoked',True)]:
 old=getattr(cap,field);setattr(cap,field,value);row('cap-bound-'+field,lambda:denied(cap.check));setattr(cap,field,old)
row('original-grant-default-disabled',lambda:denied(e.InferenceGrant('Ling-Independent','revision','f'*64,'synthetic-only',('127.0.0.1',8000)).validate))
target=SimpleNamespace(role='router',model=grant.model,revision=grant.revision,endpoint=SimpleNamespace(name='local',base_url='http://127.0.0.1:8000',managed=True,provider='omlx',api_prefix='/v1',credential_ref='local_omlx'))
for field,value in [('role','agent'),('model','Ling-other'),('revision','different')]:
 t=copy.deepcopy(target);setattr(t,field,value);row('target-'+field,lambda t=t:denied(lambda:cap._validate_target(t)))
for field,value in [('name','remote'),('base_url','http://127.0.0.1:2'),('managed',False),('provider','other'),('api_prefix','/v2'),('credential_ref','keychain:other')]:
 t=copy.deepcopy(target);setattr(t.endpoint,field,value);row('endpoint-'+field,lambda t=t:denied(lambda:cap._validate_target(t)))
for argv in [['/usr/sbin/lsof','-nP','-a','-iTCP:8765','-sTCP:LISTEN','-Fpufn'],['/usr/sbin/lsof','-nP','-a','-iTCP:8000','-sTCP:LISTEN','-Fpufn','-r'],['/bin/ps','-ww','-p','0','-o','ppid=,uid=,comm='],['/bin/ps','-ww','-p','1;true','-o','ppid=,uid=,comm='],['/bin/ps','-ww','-p','2147483648','-o','ppid=,uid=,comm='],['/bin/sh','-c','true']]:row('argv-'+repr(argv),lambda a=argv:not cap._argv_allowed(a))
(OUT/'capability-bounds-results.json').write_text(json.dumps(dict(candidate_sha=SHA,passed=sum(r['pass_'] for r in rows),total=len(rows),rows=rows,only_metadata_policy=True),indent=2));print(json.dumps(dict(passed=sum(r['pass_'] for r in rows),total=len(rows))))
