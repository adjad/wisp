import sys,json,copy,asyncio,tempfile,traceback
from pathlib import Path
from datetime import datetime,timedelta
from unittest.mock import patch
ROOT=Path('/Users/adijain/.codex/worktrees/router-update-integration/MOE_Project');OUT=Path('/private/tmp/wisp-router-67e4cef-gates-20261005/auditor')
sys.path.insert(0,str(ROOT));from scripts import eval_router_update as e
HEAD=e.git_revision();assert HEAD=='67e4cefa53687f265287b9d068fc549c1f7955b6'
STATE=Path(tempfile.mkdtemp(prefix='wisp-67e4cef-main-')).resolve();e.install_guard(STATE,OUT)
from service import main
from service.router.intent import validate_intent,compile_intent,InvalidIntent
from service.router.intent.validation import source_requirements,applicable_read
from service.tasks import compiler as T
from service.assistant.store import AssistantStore
NOW=datetime(2026,10,5,12);rows=[];LAST={}
def src(d,op='records',**kw):return dict(domain=d,operation=op,**kw)
def intent(*ss,excluded=()):return dict(version=1,kind='read',sources=list(ss),excluded_sources=list(excluded),unsupported_constraints=[])
def call(n,**a):return dict(name=n,args=a)
def save():(OUT/'application-results.json').write_text(json.dumps(dict(head=HEAD,state=str(STATE),passed=sum(r['pass'] for r in rows),total=len(rows),rows=rows),indent=2,ensure_ascii=False,default=str))
def check(label,f):
 LAST.clear();r=dict(id=label)
 try:r['evidence']=f();r['pass']=True
 except Exception as ex:r.update(error=repr(ex),trace=traceback.format_exc(),evidence=copy.deepcopy(LAST));r['pass']=False;print('FAIL',label,repr(ex),flush=True)
 rows.append(r)
 if len(rows)%60==0:save();print('progress',len(rows),flush=True)
async def run(p,data,expected,mode='read',context=(),assistant=None,text=None):
 case=dict(id='main-'+str(len(rows)),prompt=p,intent_response=data,expected=dict(calls=expected,sources=[]),fixture_answer=text or 'Independent frozen-head receipt.',context=list(context),approve=mode=='task')
 capture={};original=main.agent
 async def observer(body):
  response=await original(body);items=response.body_iterator
  async def it():
   async for item in items:yield item
   capture['workflow']=copy.deepcopy(main.store.latest_workflow(body['session_id']));capture['active_task']=copy.deepcopy(main.store.active_task(body['session_id']));capture['latest_task']=copy.deepcopy(main.store.latest_task(body['session_id']))
  response.body_iterator=it();return response
 with patch.object(main,'agent',observer):
  if assistant is None:r=await e.run_case(case,STATE,candidate=True)
  else:
   with patch.object(main,'assistant_store',assistant):r=await e.run_case(case,STATE,candidate=True)
 r['persisted_state']=capture;LAST.update(case=case,result=r)
 assert [call(c['name'],**c['args']) for c in r['executed_calls']]==expected,LAST
 assert not [x for x in r['events'] if x['type']=='error'],LAST
 assert capture['workflow'] is None,LAST
 if mode=='task':
  assert capture['active_task'] and capture['active_task']['status']=='failed',LAST
  assert any(x['type']=='task_plan' for x in r['events']),LAST
  assert r['answer']=='I couldn’t mark the reminder done. The requested change was not verified.',LAST
  assert not any(x.get('kind')=='scripted_intent' for x in r['raw_model_io']),LAST
 else:
  assert capture['active_task'] is None,LAST
  if mode=='read':assert r['answer'].count(case['fixture_answer'])==len(expected),LAST
  if mode=='clarify':assert any(x.get('intent_disposition')=='clarify' for x in r['events']),LAST
  if mode=='guard':assert not any(x.get('intent_disposition')=='compiled' or x.get('kind')=='scripted_intent' for x in [*r['events'],*r['raw_model_io']]),LAST
 return LAST.copy()
def app(*a,**k):return asyncio.run(run(*a,**k))
AP=["'",'’','‘','ʼ','＇'];neg=['do not','dont','never']+['don'+a+'t' for a in AP]
for n in neg:
 for action in ['check','delete']:
  title='Ledger: '+n+' '+action+' this item'
  for q1,q2 in [('"','"'),("'","'"),('“','”')]:
   p='Complete reminder called '+q1+title+q2
   def positive(p=p,title=title):
    mask=T._unquoted(p);assert len(mask)==len(p) and title not in mask,mask
    plan=T.compile_task(p,now=NOW);assert plan and plan.intent=='reminder.complete' and plan.target.value==title and plan.target.original==title,(p,plan)
    a=AssistantStore(STATE/('task-'+str(len(rows))+'.db'))
    try:
     item=a.add_manual(title,(NOW+timedelta(days=1)).timestamp())
     result=app(p,intent(src('reminders')),[call('complete_reminder',title=title,expected_id=item['id'])],mode='task',assistant=a)
     assert result['result']['persisted_state']['active_task']['target']['value']==title
     return dict(plan=plan.to_dict(),application=result)
    finally:a._db.close()
   check('R10-positive-'+n+'-'+action+'-'+q1,positive)
 for placement in ['before','after','unmatched']:
  p=(n+' complete reminder called "O’Neill"' if placement=='before' else 'Complete reminder called "O’Neill" and '+n+' delete my reminders' if placement=='after' else 'Complete reminder called "Ledger: '+n+' check this item')
  def outside(p=p):
   m=T._unquoted(p);assert len(m)==len(p) and T._NEGATED.search(m) and T.compile_task(p,now=NOW) is None,(p,m)
   return app(p,intent(src('reminders')),[],mode='guard')
  check('R10-outside-'+n+'-'+placement,outside)
for a in AP:
 p='D'+a+'Angelo don'+a+'t check my reminders'
 check('R10-possessive-'+repr(a),lambda p=p:dict(prompt=p,mask=T._unquoted(p),equal=T._unquoted(p)==p) if T._unquoted(p)==p else (_ for _ in ()).throw(AssertionError(p)))
for a in AP:
 for d in ['calendar','reminders','email','messages','notes']:
  for verb in ['read','include','check']:
   good=src('email',query='D’Angelo') if d=='notes' else src('notes',query='mint ponds')
   p=('Read email from D’Angelo' if d=='notes' else 'Find notes about mint ponds')+' and don'+a+'t '+verb+' my '+d
   data=intent(good,excluded=[d]);expected=[call('view_emails',query='D’Angelo',strict_match=True)] if d=='notes' else [call('search_notes',query='mint ponds')]
   def coverage(p=p,dom=d,allowed=good['domain'],data=data):
    assert source_requirements(p)==({allowed},{dom}),source_requirements(p)
    return dict(prompt=p,requirements=[allowed,dom],validated=bool(validate_intent(data,p,now=NOW)))
   check('R9-core-'+repr(a)+d+verb,coverage)
   for mutation in ['good','omit-read','omit-exclusion','add','add-and-omit']:
    data2=copy.deepcopy(data)
    if mutation=='omit-read':data2['sources']=[]
    if mutation in ['omit-exclusion','add-and-omit']:data2['excluded_sources']=[]
    if mutation in ['add','add-and-omit']:data2['sources'].append(src(d,'overview'))
    check('R9-main-'+repr(a)+d+verb+mutation,lambda p=p,d2=data2,x=expected,m=mutation:app(p,d2,x if m=='good' else [],mode='read' if m=='good' else 'clarify'))
for a in AP:
 p='Find notes about mint ponds don'+a+'t read my email or messages and afterwards read my reminders'
 check('R9-later-list-'+repr(a),lambda p=p:app(p,intent(src('notes',query='mint ponds'),src('reminders'),excluded=['email','messages']),[call('search_notes',query='mint ponds'),call('search_reminders',query='',scope='all')]))
 literal='Ledger: don'+a+'t check this item';p='Find notes about "'+literal+'" and don’t check my reminders'
 check('R10-quoted-read-exclusion-'+repr(a),lambda p=p,q=literal:app(p,intent(src('notes',query=q),excluded=['reminders']),[call('search_notes',query=q)]))
for tail in ['do not share it with Avery','never send it to Avery','without sharing it with Avery','I’d prefer not to share it with Avery','would you mind not sharing it with Avery','do not delete it']:
 p='Find notes about mint ponds and '+tail
 check('R7-'+tail,lambda p=p:app(p,intent(src('notes',query='mint ponds')),[call('search_notes',query='mint ponds')]))
for join in ['and','plus','&','and afterwards']:
 p='Find notes about mint ponds and do not share it with Avery '+join+' read my reminders'
 check('R8-later-read-'+join,lambda p=p:app(p,intent(src('notes',query='mint ponds'),src('reminders')),[call('search_notes',query='mint ponds'),call('search_reminders',query='',scope='all')]))
 check('R8-later-omit-'+join,lambda p=p:app(p,intent(src('notes',query='mint ponds')),[],mode='clarify'))
 for effect in ['update my reminders','mark my reminders complete','clear my reminders']:
  p='Find notes about mint ponds and do not delete it '+join+' '+effect
  def effect_guard(p=p):
   assert not applicable_read(p)
   try:validate_intent(intent(src('notes',query='mint ponds')),p,now=NOW)
   except InvalidIntent:pass
   else:raise AssertionError('effect accepted as read')
   return app(p,intent(src('notes',query='mint ponds')),[],mode='guard')
  check('R8-effect-'+join+effect,effect_guard)
CASES=[('calendar-only','Read appointments on my calendar tomorrow',intent(src('calendar',time={'named':'tomorrow'})),[call('get_upcoming',period='tomorrow',calendar_only=True)],'read'),('mixed-sources','Read email from Rowan and recap my texts',intent(src('email',query='Rowan'),src('messages','overview')),[call('view_emails',query='Rowan',strict_match=True),call('summarize_messages')],'read'),('mixed-omission','Read email from Rowan and recap my texts',intent(src('email',query='Rowan')),[],'clarify'),('messages-strict','Read messages about pier pickup',intent(src('messages',query='pier pickup')),[call('view_messages',query='pier pickup',strict_match=True)],'read'),('duration','Find a 75 minute free slot on my calendar tomorrow',intent(src('calendar','free_time',minutes=75,time={'named':'tomorrow'})),[call('find_free_time',period='tomorrow',minutes=75)],'read'),('unsupported-week','Read reminders this week',intent(src('reminders',time={'named':'this week'})),[],'clarify'),('unsupported-filter','Recap email from Rowan',intent(src('email','overview',query='Rowan')),[],'clarify'),('date','Read email for 2026-10-01',intent(src('email',time={'date':'2026-10-01'})),[call('view_emails',period='2026-10-01')],'read')]
for label,p,d,x,m in CASES:check(label,lambda p=p,d=d,x=x,m=m:app(p,d,x,mode=m))
p='Read two unread emails from Rowan in account "Office" for 2026-10-01; read three emails from Tessa in account "Home" for 2026-10-02'
good=intent(src('email',query='Rowan',unread=True,count=2,account='Office',time={'date':'2026-10-01'}),src('email',query='Tessa',count=3,account='Home',time={'date':'2026-10-02'}))
for k in ['time','query','account','count','operation','unread','missing']:
 bad=copy.deepcopy(good)
 if k=='missing':bad['sources'].pop()
 elif k=='operation':bad['sources'][0][k]='overview'
 elif k=='unread':bad['sources'][0].pop('unread');bad['sources'][1]['unread']=True
 else:bad['sources'][0][k],bad['sources'][1][k]=bad['sources'][1][k],bad['sources'][0][k]
 def tuplecheck(d=bad):
  assert validate_intent(good,p,now=NOW)
  try:validate_intent(d,p,now=NOW)
  except InvalidIntent:return dict(prompt=p,good=good,bad=d,rejected=True)
  raise AssertionError('whole tuple mutation accepted')
 check('R1-tuple-'+k,tuplecheck)
for fragment in ['Actually about fern charts','Instead named fern charts']:
 context=[dict(role='user',content='Find five notes about mint ponds from yesterday'),dict(role='assistant',content='Synthetic prior scope.',tool_digest='search_notes')]
 good=intent(src('notes',query='fern charts',count=5,time={'named':'yesterday'}));bad=intent(src('notes',query='mint ponds',count=5,time={'named':'yesterday'}))
 check('R2-new-'+fragment,lambda p=fragment,d=good,c=context:app(p,d,[call('search_notes',query='fern charts',count=5,period='yesterday')],context=c))
 check('R2-stale-'+fragment,lambda p=fragment,d=bad,c=context:app(p,d,[],mode='clarify',context=c))
for title in ['Guide to Piers','Road to Harbor Maps','Send Instructions']:
 p='Read email from Rowan and email about '+title
 check('R4-'+title,lambda p=p,q=title:app(p,intent(src('email',query='Rowan'),src('email',query=q)),[call('view_emails',query='Rowan',strict_match=True),call('view_emails',query=q,strict_match=True)]))
check('source-failure',lambda:app('Find notes about mint ponds',intent(src('notes',query='mint ponds')),[call('search_notes',query='mint ponds')],text='(error: synthetic Notes source unavailable)'))
save();print(json.dumps(dict(passed=sum(r['pass'] for r in rows),total=len(rows),failures=[dict(id=r['id'],error=r.get('error')) for r in rows if not r['pass']]),ensure_ascii=False))
