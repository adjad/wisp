import sys,os,json,asyncio,tempfile,traceback,inspect,copy,time
from pathlib import Path
from unittest.mock import patch
ROOT=Path('/Users/adijain/.codex/worktrees/router-update-integration/MOE_Project');OUT=Path('/private/tmp/wisp-router-67e4cef-gates-20261005/auditor')
sys.path.insert(0,str(ROOT));from scripts import eval_router_update as e
HEAD=e.git_revision();assert HEAD=='67e4cefa53687f265287b9d068fc549c1f7955b6'
STATE=Path(tempfile.mkdtemp(prefix='wisp-67e4cef-retained-')).resolve();e.install_guard(STATE,OUT)
import pytest
from tests import test_router_intent_core as C,test_router_overview_grounding as O,test_router_overview_message_scope as S,test_message_digest as P
from service.router.intent import planner
from service import main
from service.router import router
from service.router.web_request import classify
from service.tools import imessage_tools as M,message_digest as D
from scripts import run_simulation_qa as G
rows=[]
def check(label,f):
 r=dict(id=label)
 try:r['evidence']=f();r['pass']=True
 except Exception as ex:r.update(error=repr(ex),trace=traceback.format_exc());r['pass']=False;print('FAIL',label,repr(ex),flush=True)
 rows.append(r)
def fixture(f,*args):
 with pytest.MonkeyPatch.context() as mp:
  P.isolated.__wrapped__(mp)
  f(*([mp,*args] if next(iter(inspect.signature(f).parameters),'')=='monkeypatch' else args))
 return dict(function=f.__module__+'.'+f.__name__,parameters=args)
with patch.object(planner,'role_target',lambda r:C.TARGET if r=='router' else None):
 for n in ['test_one_repair_and_clean_role_context_metadata','test_invalid_intent_never_falls_back_to_broad_tools','test_unavailable_model_never_loads_or_generates','test_remote_or_wrong_model_is_not_resource_eligible','test_deadline_cancels_generation_without_retry','test_outer_cancellation_is_not_reclassified_as_clarification','test_schema_asset_matches_callable_contract','test_loop_merge_keeps_scope_and_failure_evidence','test_registered_strict_message_capability_is_used_exactly','test_missing_binding_or_resolution_failure_fails_closed','test_scope_labels_escape_literal_markdown_and_preserve_failed_receipt']:
  check(n,lambda n=n:fixture(getattr(C,n)))
 for cfg in [{},dict(enabled=False),dict(enabled=True),dict(enabled=True,domains=[]),dict(enabled=True,domains=['notes'])]:check('intent-default-denial-'+repr(cfg),lambda cfg=cfg:fixture(C.test_defaultoff_and_domain_allowlist_do_not_generate,cfg))
 check('intent-kill',lambda:fixture(C.test_kill_switch_never_generates))
 for mut in [lambda c:setattr(c,'base_url','https://remote.example.invalid'),lambda c:setattr(c,'provider',None),lambda c:setattr(c,'_credential_transport',None)]:
  def identity(mut=mut):
   c=C.FakeClient();mut(c);r=asyncio.run(planner.plan_read('Recap my email',client=c,model=C.MODEL,config=C.CONFIG));assert r.disposition=='clarify' and not c.calls,(r,c.calls);return dict(disposition=r.disposition,calls=c.calls)
  check('intent-identity-before-IO-'+str(len(rows)),identity)
for now,collision in [(1791222000.0,None),(1791234567.0,'1234'),(1791256782.0,'5678')]:check('G1-clock-'+str(now),lambda n=now,c=collision:fixture(P.test_distinct_redacted_requests_keep_both_source_occurrences,n,c))
def oracle():
 with pytest.MonkeyPatch.context() as mp:
  P.isolated.__wrapped__(mp);real=M.filter_summary_message_rows
  def leak(*a,**kw):return [D.SummaryRow((r[0],r[1],r[2]+' 1234'),r.source_before,r.source_after) for r in real(*a,**kw)]
  mp.setattr(M,'filter_summary_message_rows',leak)
  try:P.test_distinct_redacted_requests_keep_both_source_occurrences(mp,1791234567.0,'1234')
  except AssertionError:return dict(injected_text_leak_rejected=True)
  raise AssertionError('privacy oracle accepted injected text')
check('G1-injected-leak',oracle)
for n,f in vars(O).items():
 if n.startswith('test_'):
  args=list(inspect.signature(f).parameters)
  if 'state' in args:
   for state in ['ready','unavailable','syncing']:check(n+'-'+state,lambda f=f,s=state:fixture(f,s))
  elif args==['rows']:
   for v in [[],[O.mail('Independent overview fact')]]:check(n+'-'+str(len(v)),lambda f=f,v=v:fixture(f,v))
  else:check(n,lambda f=f:fixture(f))
for n,f in vars(S).items():
 if n.startswith('test_'):check(n,lambda f=f:fixture(f))
def manifest():
 names=G._selected_tests(['full']);assert len(names)==179;return dict(module_count=len(names),new_paths=[x for x in names if 'router_intent' in x or 'router_update_eval' in x or 'router_overview' in x])
check('manifest-179',manifest)
for k in ['unknown','missing']:
 def drift(k=k):
  rt=STATE/('manifest-'+k);(rt/'tests').mkdir(parents=True)
  for n in G.SAFE_FULL_TESTS:
   p=rt/n;p.parent.mkdir(parents=True,exist_ok=True);p.touch()
  if k=='unknown':(rt/'tests/test_unknown_fixture.py').touch()
  else:(rt/next(iter(sorted(G.SAFE_FULL_TESTS)))).unlink()
  with patch.object(G,'ROOT',rt):
   try:G._selected_tests(['full'])
   except RuntimeError:return dict(drift=k,rejected=True)
  raise AssertionError('manifest drift accepted')
 check('manifest-'+k,drift)
for clock,hours in [('2026-03-08T12:00:00-07:00',23),('2026-11-01T12:00:00-08:00',25)]:
 for host in ['UTC','America/Los_Angeles']:
  def dst(clock=clock,hours=hours,host=host):
   old=os.environ.get('TZ')
   try:
    os.environ['TZ']=host;time.tzset();a=e.canonical_args('view_messages',dict(day=clock[:10]),{},clock=clock);b=e.canonical_args('view_messages',dict(period='today'),{},clock=clock);c=e.canonical_args('view_messages',dict(period='tomorrow'),{},clock=clock);assert a==b and a!=c and a['_resolved_span'][1]-a['_resolved_span'][0]==hours*3600 and os.environ['TZ']==host;return dict(clock=clock,host=host,args=a,hours=hours)
   finally:
    if old is None:os.environ.pop('TZ',None)
    else:os.environ['TZ']=old
    time.tzset()
  check('DST-'+clock+host,dst)
def scorer():
 d=e.score(dict(expected=dict(calls=[dict(name='search_notes',args=dict(query='fern',count=2))],sources=['notes'])),dict(executed_calls=[dict(name='search_notes',args=dict(query='fern',count=2.0))],events=[dict(type='done')],schemas={},answer=''))['metrics'];assert d['exact_arguments'] is True and d['request_argument'] is False;return d
check('P3-scorer',scorer)
check('actual-config-default-off',lambda:dict(default_disabled=True) if main.models_config().get('intent_router',{}).get('enabled') is not True else (_ for _ in ()).throw(AssertionError('enabled')))
# Fresh public subject and delivery boundaries. Classification only; no lookups/sends.
def routed(p,prior=None):
 with patch.object(router,'role_to_model',lambda role:'Other-Fixture-Model'):return asyncio.run(router.route(p,last_user=prior,last_tools='web_search' if prior else None))
for p in ['update me on the situation in Taiwan','give me an update on the situation in Iran','what changed today in Taiwan','latest developments in Peru']:
 def public(p=p):
  d=routed(p);assert d.direct_calls==[('web_search',dict(query=p))] and d.tool_subset==['web_search'] and {'run_shell','http_request'}<=d.forbidden_tools;return dict(prompt=p,direct_calls=d.direct_calls,subset=d.tool_subset)
 check('public-'+p,public)
source='search the web for the Neravian accord'
for sep in [' and ','; ','. ',' & ','; afterwards ',', and afterwards ']:
 for verb in ['email','send','forward']:
  def delivery(sep=sep,verb=verb):
   p=source+sep+verb+' it to fern@example.invalid';d=routed(p);assert d.tool_subset==['web_search','send_email'] and not d.direct_calls and d.tool_argument_bindings['web_search']==dict(query=source) and d.tool_argument_bindings['send_email']==dict(to='fern@example.invalid') and 'lookup_contact' in d.forbidden_tools;return dict(prompt=p,bindings=d.tool_argument_bindings,subset=d.tool_subset)
  check('public-literal-address-'+sep+verb,delivery)
for p in ['email it to Mom','forward it to Mom by email']:
 def inherited(p=p):
  d=routed(p,source);assert d.tool_subset==['web_search','lookup_contact','send_email'] and d.tool_argument_bindings['web_search']==dict(query=source);return dict(prompt=p,bindings=d.tool_argument_bindings)
 check('public-inherited-'+p,inherited)
for tail in ['cancel the web search','cancel that search','don’t browse']:
 def cancel(t=tail):
  p='look up the latest Python release online; '+t;c=classify(p);d=routed(p);assert not c.allowed and not d.direct_calls and 'web_search' not in (d.tool_subset or []);return dict(prompt=p,subset=d.tool_subset)
 check('public-cancel-'+tail,cancel)
for tail in ['without sending it','; don’t send it','; do not deliver it']:
 def revoke(t=tail):
  p=source+' and email it to Mom '+t;c=classify(p);d=routed(p);assert c.delivery_cancelled and c.delivery is None and not any(x in (d.tool_subset or []) for x in ['send_email','send_message','lookup_contact']) and d.tool_argument_bindings['web_search']==dict(query=source);return dict(prompt=p,subset=d.tool_subset)
 check('public-revoked-'+tail,revoke)
(OUT/'retained-results.json').write_text(json.dumps(dict(candidate_sha=HEAD,state=str(STATE),passed=sum(r['pass'] for r in rows),total=len(rows),rows=rows),indent=2,default=str));print(json.dumps(dict(passed=sum(r['pass'] for r in rows),total=len(rows),failures=[r['id'] for r in rows if not r['pass']])))
