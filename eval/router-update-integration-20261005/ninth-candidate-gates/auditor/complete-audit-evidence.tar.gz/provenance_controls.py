from pathlib import Path
import hashlib,json,gzip,subprocess,sys
ROOT=Path('/Users/adijain/.codex/worktrees/router-update-integration/MOE_Project');OUT=Path('/private/tmp/wisp-router-67e4cef-gates-20261005/auditor')
SHA='67e4cefa53687f265287b9d068fc549c1f7955b6';BASE='4994caa15533c0cf84c07208c9097e4197f2815b';OLD='44babb70ee2eea99897b9437b2f6d49b2d59adff'
def h(b):return hashlib.sha256(b).hexdigest()
def git(*a):return subprocess.check_output(['/usr/bin/git',*a],cwd=ROOT)
rows=[]
def check(n,a,b):rows.append(dict(id=n,actual=a,expected=b,pass_=a==b))
head=git('rev-parse','HEAD').decode().strip();check('exact-head',head,SHA);check('clean',git('status','--porcelain').decode(),'')
check('base-ancestor',subprocess.run(['/usr/bin/git','merge-base','--is-ancestor',BASE,SHA],cwd=ROOT).returncode,0)
full=git('diff','--name-only',BASE,SHA).decode().splitlines();delta=git('diff','--name-only',OLD,SHA).decode().splitlines();check('full-diff-count',len(full),449);check('delta-count',len(delta),96)
source=[p for p in delta if p.startswith(('service/','scripts/','tests/','native/'))];check('exact-source-test-delta',source,['scripts/eval_router_update.py','service/tasks/compiler.py','tests/test_router_intent_core.py','tests/test_router_intent_main.py','tests/test_router_update_eval.py'])
files={p:h((ROOT/p).read_bytes()) for p in full}
# Working bytes independently match frozen Git objects; opaque evidence remains opaque.
work_blobs=git('hash-object','--',*full).decode().splitlines()
for p,blob in zip(full,work_blobs):check('working-object:'+p,blob,git('rev-parse',SHA+':'+p).decode().strip())
registry=Path('/Users/adijain/Documents/Codex/2026-10-05/new-chat/WISP_ROUTER_1_3_IMPLEMENTATION_OWNERSHIP_2026-10-05.json');x=json.JSONDecoder().raw_decode(registry.read_text())[0]['exactCandidateGateAssignments20261005']
check('registry-sha',x['exactSHA'],SHA);check('assignment-pin',h(Path(x['assignmentDocument']).read_bytes()),x['assignmentDocumentSHA256'])
cv=x['candidateVerification'];check('freeze-pin',h(Path(cv['freezeReceipt']).read_bytes()),cv['freezeReceiptSHA256'])
integration=ROOT/'eval/router-update-integration-20261005'
for f,k in [('HANDOFF.md','handoffSHA256'),('progress.json','progressSHA256')]:check('integration-'+f,h((integration/f).read_bytes()),cv[k])
for key in ['coreCompletionReference','runtimeBridgeImplementationCompletionReference']:
 w=x[key];check(key+'-handoff',h(Path(w['handoff']).read_bytes()),w['handoffSHA256'])
 for p in w.get('sourceFiles',w.get('exactWritePaths',[])):check(key+'-Git-byte-match:'+p,git('rev-parse',SHA+':'+p).decode().strip(),git('rev-parse',w['workerSHA']+':'+p).decode().strip())
 for p,pin in w.get('fileFingerprintsVerified',{}).items():check(key+'-file-pin:'+p,files[p],pin)
 for pathkey,pinkey in [('manifest','manifestSHA256')]:
  if pathkey in w:check(key+'-manifest-pin',h(Path(w[pathkey]).read_bytes()),w[pinkey])
for f in ['dev.jsonl','test.jsonl','author_corpus.py','seal.json']:
 p='eval/router-update-20261005/'+f;check('unchanged-corpus-gold:'+f,h((ROOT/p).read_bytes()),h(git('show',OLD+':'+p)))
# Only SHA256 bytes are used; no dev/test or author script is decoded/executed.
seal=json.loads((ROOT/'eval/router-update-20261005/seal.json').read_text())
for split in ['dev','test']:check('unchanged-seal-hash-only:'+split,h((ROOT/'eval/router-update-20261005'/(split+'.jsonl')).read_bytes()),seal['splits'][split]['sha256'])
prior=x['currentCandidateEvidencePreservation'];check('eighth-complete-bundle-pin',h(Path(prior['manifest']).read_bytes()),prior['manifestSHA256'])
archive_entries=0;archive_manifests=0
for mf in sorted(integration.rglob('*sha256.json')):
 if '-candidate-gates' not in str(mf):continue
 archive_manifests+=1;d=json.loads(mf.read_text())
 if isinstance(d,dict) and 'entries' in d:d=d['entries']
 if isinstance(d,list):
  for row in d:
   p=Path(row['path']);check('external-original:'+str(mf.relative_to(ROOT))+':'+p.name,h(p.read_bytes()) if p.exists() else 'MISSING',row['sha256']);archive_entries+=1
  continue
 if 'files' in d:d=d['files']
 for name,pin in d.items():
  if not isinstance(pin,(str,dict)) or isinstance(pin,str) and len(pin)!=64:continue
  p=mf.parent/name
  if p.exists():
   b=p.read_bytes();stored=pin if isinstance(pin,str) else pin['stored_sha256'];check('stored-archive:'+str(p.relative_to(ROOT)),h(b),stored)
   if isinstance(pin,dict) and 'original_sha256' in pin:check('original-archive:'+str(p.relative_to(ROOT)),h(gzip.decompress(b)) if p.suffix=='.gz' else h(b),pin['original_sha256'])
  elif isinstance(pin,str) and Path(str(p)+'.gz').exists():check('restored-original:'+str(p.relative_to(ROOT)),h(gzip.decompress(Path(str(p)+'.gz').read_bytes())),pin)
  else:check('missing-archive:'+str(p.relative_to(ROOT)),'MISSING',pin)
  archive_entries+=1
replays=[]
for parent in [ROOT/'eval/router-update-20261005',integration]:
 for mf in parent.glob('*/manifest.json'):
  raw=mf.parent/'raw.jsonl.gz'
  if not raw.exists():continue
  meta=json.loads(mf.read_text());compressed=raw.read_bytes();restored=gzip.decompress(compressed)
  for k in ['raw_sha256','raw_jsonl_sha256']:
   if k in meta:check('replay-manifest:'+str(mf.parent.relative_to(ROOT))+':'+k,h(restored),meta[k])
  d=json.loads((mf.parent/'checksums.json').read_text())
  for name,pin in d.items():
   if not isinstance(pin,(str,dict)):continue
   if name in ['raw_sha256','raw_jsonl_sha256']:b=restored
   elif name in ['raw_gzip_sha256','raw_jsonl_gzip_sha256','gzip_sha256']:b=compressed
   elif name=='manifest_sha256':b=mf.read_bytes()
   else:b=(mf.parent/name).read_bytes()
   check('replay-pin:'+str(mf.parent.relative_to(ROOT))+':'+name,h(b),pin if isinstance(pin,str) else pin['stored_sha256'])
   if isinstance(pin,dict) and 'original_sha256' in pin:check('replay-restored:'+str(mf.parent.relative_to(ROOT))+':'+name,h(gzip.decompress(b)) if name.endswith('.gz') else h(b),pin['original_sha256'])
  replays.append(dict(path=str(mf.parent.relative_to(ROOT)),raw_sha256=h(restored),gzip_sha256=h(compressed),metadata=meta))
receipt=Path('/private/tmp/wisp-router-update-67e4cef-gate-receipt.json');gate=None
if receipt.exists():
 gate=json.loads(receipt.read_text());(OUT/'parent-gate-receipt.json').write_bytes(receipt.read_bytes());check('parent-gate-candidate',gate.get('candidate_sha',gate.get('head')),SHA);check('parent-exit',gate['exit_code'],0);check('parent-head-unchanged',gate['head_unchanged'],True);check('parent-clean',gate['status_porcelain'],'');check('parent-opaque-log-sha',h(Path(gate['log']).read_bytes()),gate['log_sha256'])
ci=[]
for p in Path('/private/tmp').glob('wisp-router-update-67e4cef*ci*.json'):
 d=json.loads(p.read_text());(OUT/p.name).write_bytes(p.read_bytes())
 ci.append(dict(path=str(p),sha256=h(p.read_bytes()),metadata=d))
 if 'headSha' in d:check('CI-exact-head:'+p.name,d['headSha'],SHA)
 # Download receipt/log hashes are metadata only; never inspect log/provider payloads.
 for key,pin in d.items():
  if 'sha256' in key and isinstance(pin,str) and len(pin)==64:
   possible=[d.get('log'),d.get('path'),d.get('log_path'),d.get('output')]
   paths=[Path(v) for v in possible if isinstance(v,str) and Path(v).is_file()]
   if len(paths)==1:check('CI-download-log-pin:'+p.name,h(paths[0].read_bytes()),pin)
report=dict(candidate_sha=SHA,base_sha=BASE,previous_sha=OLD,full_paths=full,delta_paths=delta,files=files,source_paths=source,rows=rows,passed=sum(r['pass_'] for r in rows),total=len(rows),archive_manifests=archive_manifests,archive_entries=archive_entries,replay_bundles=replays,parent_gate=gate,ci=ci,checksum_authority=x['checksumOnlyAuthority'],prior_results='Opaque integrity only; no earlier gates transfer')
(OUT/('provenance-final.json' if '--final' in sys.argv else 'provenance.json')).write_text(json.dumps(report,indent=2))
print(json.dumps(dict(passed=report['passed'],total=len(rows),archives=archive_entries,manifests=archive_manifests,replays=len(replays),failures=[r['id'] for r in rows if not r['pass_']])))
