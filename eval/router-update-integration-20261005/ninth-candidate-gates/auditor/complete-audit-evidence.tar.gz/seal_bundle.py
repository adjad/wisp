from pathlib import Path
import hashlib, json, os, subprocess

OUT = Path('/private/tmp/wisp-router-67e4cef-gates-20261005/auditor')
ROOT = Path('/Users/adijain/.codex/worktrees/router-update-integration/MOE_Project')
SHA = '67e4cefa53687f265287b9d068fc549c1f7955b6'
def h(b): return hashlib.sha256(b).hexdigest()
prov = json.loads((OUT / 'provenance-final.json').read_text())
assert subprocess.check_output(['/usr/bin/git','rev-parse','HEAD'], cwd=ROOT).decode().strip() == SHA
assert subprocess.check_output(['/usr/bin/git','status','--porcelain=v1'], cwd=ROOT) == b''
for name, pin in prov['files'].items(): assert h((ROOT / name).read_bytes()) == pin, name
bounded = json.loads((OUT / 'R11_FINDING_CHECKSUMS.json').read_text())
for name, pin in bounded['files'].items(): assert h((OUT / name).read_bytes()) == pin, name
files = {}
for directory, dirs, names in os.walk(OUT, followlinks=False):
    linkdirs = [name for name in dirs if (Path(directory) / name).is_symlink()]
    for name in sorted(names + linkdirs):
        p = Path(directory) / name
        relative = str(p.relative_to(OUT))
        if relative == 'CHECKSUMS.json': continue
        if p.is_symlink():
            target = os.readlink(p)
            files[relative] = {'kind':'symlink','target':target,'sha256':h(target.encode('utf-8'))}
        else:
            data = p.read_bytes()
            files[relative] = {'kind':'file','bytes':len(data),'sha256':h(data)}
manifest = {'candidate_sha':SHA,'verdict':'BLOCK','file_count':len(files),
            'method':'Recursive byte seal; symlinks hash UTF-8 target text without dereference; checksum manifest excludes itself.',
            'files':dict(sorted(files.items()))}
seal = OUT / 'CHECKSUMS.json'
seal.write_text(json.dumps(manifest,indent=2)+'\n')
for name, row in files.items():
    p = OUT / name
    b = os.readlink(p).encode('utf-8') if row['kind'] == 'symlink' else p.read_bytes()
    assert h(b) == row['sha256'], name
print(json.dumps({'candidate_sha':SHA,'verdict':'BLOCK','sealed_files':len(files),
    'seal_sha256':h(seal.read_bytes()),'report_sha256':h((OUT/'REPORT.md').read_bytes()),
    'handoff_sha256':h((OUT/'HANDOFF.json').read_bytes()),'all_entries_verified':True}))
