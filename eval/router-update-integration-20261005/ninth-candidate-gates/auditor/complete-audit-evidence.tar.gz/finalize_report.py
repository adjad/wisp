from pathlib import Path
import hashlib, json, shutil, subprocess
from datetime import datetime, timezone

OUT = Path('/private/tmp/wisp-router-67e4cef-gates-20261005/auditor')
ROOT = Path('/Users/adijain/.codex/worktrees/router-update-integration/MOE_Project')
SHA = '67e4cefa53687f265287b9d068fc549c1f7955b6'
BASE = '4994caa15533c0cf84c07208c9097e4197f2815b'
def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def read(name): return json.loads((OUT / name).read_text())
def write(name, obj): (OUT / name).write_text(json.dumps(obj, indent=2) + '\n')

# All receipt/log copies are opaque byte preservation, not payload interpretation.
pins = {
    'wisp-router-update-67e4cef-regression.log': 'c24a0cf2722c0034069f7bf21f27233ff6f7a16e87da73d6dbed9d03a8069cac',
    'wisp-router-update-67e4cef-python-ci.log': 'eec21f8fecb65a18f18f96729d9fbd41b6364832e379fe8d3cc768d7411f46ed',
    'wisp-router-update-67e4cef-artifact-ci.log': 'dce2bea8dac79142fe43d741386a792b5467782e871d6ec7791df0ed61579be1',
    'wisp-router-update-67e4cef-artifact-ci-final.json': '5e31a9d6fb1a5727e4750ef435a9a6017589a6292374ae6c52238819469b3917',
}
for name, pin in pins.items():
    p = Path('/private/tmp') / name
    assert digest(p) == pin, name
    shutil.copyfile(p, OUT / name)
    assert digest(OUT / name) == pin

bounded = read('R11_FINDING_CHECKSUMS.json')
for name, pin in bounded['files'].items(): assert digest(OUT / name) == pin, name
assert digest(OUT / 'R11_FINDING_CHECKSUMS.json') == '1e6e357a268161e75dc8d60c48767d135fa77f331656b60237f51caafaf89a3a'
prov = read('provenance-final.json')
assert prov['passed'] == prov['total'] == 1473
assert read('provenance.json')['files'] == prov['files']
head = subprocess.check_output(['/usr/bin/git', 'rev-parse', 'HEAD'], cwd=ROOT).decode().strip()
clean = subprocess.check_output(['/usr/bin/git', 'status', '--porcelain=v1'], cwd=ROOT).decode()
assert head == SHA and clean == '', (head, clean)

groups = {}
for key, name in [('application', 'application-results.json'), ('retained', 'retained-results.json'),
                  ('task_scope', 'task-scope-results.json'), ('capability_bounds', 'capability-bounds-results.json')]:
    d = read(name)
    groups[key] = {'passed': d['passed'], 'total': d['total'], 'evidence': name}
modes = {}
for mode in ['stream', 'policy', 'cancel', 'generation', 'contention', 'marker', 'managed', 'identity', 'missing', 'symlink', 'race']:
    name = 'runtime-' + mode + '-results.json'
    d = read(name)
    modes[mode] = {'passed': d['passed'], 'total': d['total'], 'evidence': name}
runtime = {'passed': sum(d['passed'] for d in modes.values()), 'total': sum(d['total'] for d in modes.values()), 'modes': modes}
assert runtime['passed'] == 129 and runtime['total'] == 133
python_ci = read('wisp-router-update-67e4cef-python-ci-final.json')
artifact_ci = read('wisp-router-update-67e4cef-artifact-ci-final.json')
for ci in [python_ci, artifact_ci]:
    assert ci['headSha'] == SHA and ci['conclusion'] == 'success' and ci['status'] == 'completed'
assert all(j['conclusion'] == 'skipped' for j in artifact_ci['jobs'] if j['databaseId'] in [112095669103, 112095669820])
now = datetime.now(timezone.utc).isoformat()
limits = [
    'Structured planner and evaluation runtime capability remain default disabled; no feature activation or CLI runtime enablement.',
    'HTTP MockTransport and sys.audit policy events establish isolation behavior only, not actual sockets, transport authority, model residency, readiness, loaded-weight provenance, performance or model quality.',
    'No live model, native effects, production auth, private user data, external communications, provider cancellation diagnosis, training, deployment, publishing, installed-app replacement or merges performed.',
    'Simulation QA remains held pending a nonblocking same-SHA independent audit and explicit source-parent release. R11 BLOCK does not satisfy this requirement.',
    'Actual runtime evaluation still requires separately attributed current identity/readiness/provenance, a valid exclusive resource window and same-SHA auth audit/QA; no invented loaded-weight hash.',
    'The retained provider-cancellation cause and Claude owner acknowledgement/relay remain unresolved; passing CI does not diagnose them.',
    'All prior gates remain commit-bound; any repair or new HEAD requires fresh acceptance and gates.',
    'Direct user instruction targets Wisp 1.3.0 and forbids merging; PR #160 stays draft and unmerged.',
]
r10 = {
    'disposition': 'CLOSED_FOR_SUPPORTED_EXISTING_GRAMMAR',
    'change': 'Seven existing negation checks and three existing reminder selectors apply the unchanged quote mask; extraction retains original literal title/body bytes. Patterns, order and grammar are unchanged.',
    'positive_controls': '16/16 straight double-quoted cases and 14/14 recognized single-quoted cases; exact fake complete/delete target arguments and singular expected_id.',
    'other_controls': '24/24 true outside negations, 5/5 unmatched/possessive boundaries, 5/5 quoted-data reads with real outside exclusions, and 7/7 individual typed compiler controls.',
    'truthfulness': 'Unmutated synthetic reminder readback yields persisted failed task and truthful requested-change-not-verified response; workflow and active/latest task snapshots retained.',
    'exploratory_notes': '18 raw application assertions remain failed: 16 curly-double-quote title delimiter expectations and 2 nested ASCII apostrophe-in-single-quote mask expectations. Paired plain controls/source comparison show unchanged grammar limitations; these are not R10 regressions and are not credited as passes.',
    'unsupported_syntax': 'Check off reminder called remains unsupported and is not used as a valid regression oracle.',
    'evidence': ['application-results.json', 'task-scope-results.json', 'exploratory-grammar-observations.json'],
}
ci = {
    'local': {'result': 'PASS', 'passed': 179, 'total': 179, 'receipt': 'parent-gate-receipt.json', 'log_sha256': pins['wisp-router-update-67e4cef-regression.log'], 'duplicate_gate_run': False},
    'python': {'result': 'SUCCESS', 'run': 37407801476, 'job': 112089162704, 'metadata': 'wisp-router-update-67e4cef-python-ci-final.json', 'log_sha256': pins['wisp-router-update-67e4cef-python-ci.log']},
    'artifact': {'result': 'SUCCESS', 'run': 37407801472, 'job': 112089162874, 'metadata': 'wisp-router-update-67e4cef-artifact-ci-final.json', 'log_sha256': pins['wisp-router-update-67e4cef-artifact-ci.log'], 'release_publish_jobs': 'both skipped'},
    'interpretation': 'All mechanical/CI receipts are exact candidate. They do not override the independent R11 isolation-policy BLOCK.'
}
report = {
    'artifact_type': 'independent_exact_head_release_audit', 'audit_number': 9,
    'recorded_at_utc': now, 'candidate_sha': SHA, 'base_sha': BASE,
    'previous_candidate_sha': '44babb70ee2eea99897b9437b2f6d49b2d59adff',
    'pr_url': 'https://github.com/adjad/wisp/pull/160', 'branch': 'codex/router-update-1-3',
    'target_version': '1.3.0', 'verdict': 'BLOCK', 'blocking_findings': [read('R11_FINDING.json')],
    'bounded_finding_sha256': digest(OUT / 'R11_FINDING.json'),
    'bounded_finding_seal_sha256': digest(OUT / 'R11_FINDING_CHECKSUMS.json'),
    'source_review': {
        'full_intended_diff_paths': 449, 'delta_since_previous_paths': 96,
        'source_test_delta': prov['source_paths'],
        'method': 'Full new compiler/runtime bridge source, surrounding context, tests/docs and retained routing/overview contracts reviewed. Previously reviewed unchanged source/schema/harness context retained only after exact delta and all 449 working Git blob matches; no earlier gate pass transferred.',
        'working_fingerprints_unchanged': True, 'final_clean_head_verified': True,
    },
    'r10': r10, 'verification': {'groups': groups, 'runtime_factory': runtime,
        'actual_main_controls': 481,
        'retained_detail': 'R9 455/455, R7 6/6, R8 20/20; source/privacy/task/overview, exact provenance/actors/counts, omission/addition/exclusion, planner deadline/cancel/repair/default-off/schema/residency, manifest 179 fail-closed discovery, DST 23/25h and TZ restore, public-address delivery/cancel/revoke controls.',
        'repeat_stream_and_direct_probe': 'Corroboration only, not double counted',
        'execution': 'Fresh authored controls and current source test oracles with synthetic fixtures/inert fakes. No archived audit script execution or semantic corpus replay.'},
    'provenance': {'passed': 1473, 'total': 1473, 'archive_manifests': 26, 'archive_entries': 611, 'replay_bundles': 13,
        'evidence': 'provenance-final.json', 'method': 'Opaque original/restored byte hashes, manifest metadata and assignment/freeze/worker/Git pins only; no corpus/author/heldout/archived payload interpretation.'},
    'ci': ci, 'fixture_corrections': read('fixture-corrections.json'),
    'limitations_and_holds': limits,
    'required_repair': 'Restore caller context before async-generator yields and invalidate inherited context authority after owned operation closure. Add consumer and copied-child-task denial tests while preserving genuine auth/recovery/lock/expiry/cancellation cleanup. Sole repair owner must be recorded by Orchestrator; auditor made no source edits.',
    'sealing': 'CHECKSUMS.json recursively seals every output file except itself. Symlinks are hashed as UTF-8 link target bytes and never dereferenced. The bounded 10-entry finding seal remains unchanged.',
}
write('REPORT.json', report)
md = f'''# Wisp PR #160: ninth exact-head audit — BLOCK

Candidate `{SHA}`, base `{BASE}`, branch `codex/router-update-1-3`, targeting Wisp 1.3.0. PR: https://github.com/adjad/wisp/pull/160. The user forbids merging; the PR remains draft.

## P1 R11: private runtime authority escapes streaming scope

At `scripts/eval_router_update.py:577–582`, `_ScopedResidentClient.stream_events` yields while `_operation` retains the private peer ContextVar. The socket audit at line 886 treats that ambient phase as authority. Async-generator consumption exposes the phase to the caller; `asyncio.create_task` copies it. The copied child still has admitted socket-policy events and synthetic original-home resolution after the stream closes. Parent restoration and owned-stream cleanup succeed, so they do not eliminate the inherited authority.

The fresh supported-factory → ResidentInferenceAdapter reproduction uses synthetic settings/auth/locks, genuine RecoveryGate and normal auth delegation, HTTP MockTransport and `sys.audit` socket-policy events. Before the stream: no phase, socket policy denied, isolated home. Between frames: peer phase, policy admitted, fake original home. Child released after close: peer phase, policy admitted, fake original home. Four of 17 stream assertions fail. A separate inert wrapper probe independently corroborates the leak. This proves an isolation-policy bypass; it does not claim credential theft, real socket dispatch or native execution.

Repair should restore the consumer context before yielding and prevent copied contexts from authorizing I/O after operation closure. Add consumer and inherited-task denial tests; preserve auth/quarantine, pinned lock/lease, expiry/revocation, cancellation and truthful raw cleanup receipts. The Orchestrator must record one repair owner before edits. Any repair creates a new candidate requiring fresh gates.

Bounded finding: `R11_FINDING.json` SHA256 `{report['bounded_finding_sha256']}`. Its unchanged ten-entry seal: `{report['bounded_finding_seal_sha256']}`.

## R10 and application verification

The supported R10 repair closes the earlier quoted-title negation finding: 16 straight-double-quoted and 14 recognized single-quoted positive controls pass, preserving literal arguments and singular expected_id. All 24 true outside-negation, five unmatched/possessive and five read/exclusion controls pass; all seven individual typed compiler controls pass. Fake readback remains honest and task/workflow snapshots are preserved.

Raw application results are **568/586**, including 481 actual-main controls. The 18 failed exploratory assertions remain visible: 16 curly-double-quote delimiter expectations and two nested ASCII apostrophe-in-single-quote mask expectations. Paired plain controls and unchanged source establish existing grammar limitations; these are not new R10 regressions or credited passes. `Check off reminder called` remains unsupported. R9 455/455, R7 6/6 and R8 20/20 retained controls pass.

| Fresh evidence group | Result |
| --- | --- |
| Application controls | 568/586 (18 disclosed exploratory grammar failures) |
| Retained routing/overview/deadline/manifest/DST contracts | 91/91 |
| Seven typed compiler quote-scope controls | 7/7 |
| Capability default denial and bounds | 20/20 |
| Supported runtime factory modes | 129/133 (four R11 failures) |
| Exact-head provenance/integrity | 1,473/1,473 |

Runtime policy, cancellation, recovery-generation, contention, marker/managed manifest, wrong identity, missing/symlink/raced lock modes pass. Default caller denial, genuine synthetic auth delegation, parent restoration, early close and caller cancellation pass. Stream repeat/direct probe are corroboration only. The output-root fixture setup errors, correction scripts, exit-one logs and preparatory syntax-error disclosure are retained in `fixture-corrections.json`; no candidate or authority contract changed.

## Mechanical gates and integrity

The parent ran the one authorized local gate: **179/179 PASS**, exit zero, unchanged clean candidate. No duplicate gate was launched. Python CI run **37407801476**, job **112089162704**, and artifact CI run **37407801472**, job **112089162874**, both completed **SUCCESS** at this exact SHA. Both release publishing jobs were skipped. CI metadata and complete raw log bytes are preserved and hashed; these passes do not override R11.

The review covers the intended 449-path diff and 96-path delta. The five source/test delta files and full new runtime/compiler context were reviewed; retained unchanged source/contracts were confirmed by delta and frozen Git bytes. Final clean HEAD and all 449 working fingerprints match. Provenance verifies 26 archive manifests/611 entries and 13 replay bundles using opaque stored/original byte hashes and metadata only, plus assignment/freeze/worker pins. No earlier gate pass transfers; no heldout, author or archived payload was semantically inspected or executed.

## Limits and release holds

Structured planner and evaluation runtime bridge remain default disabled. Synthetic MockTransport/policy proof does not establish real transport authority, runtime readiness/residency, loaded-weight provenance, quality or performance. Actual runtime admission needs separately attributed current identity/readiness/provenance, a valid exclusive resource window and same-SHA auth audit/QA. No loaded-weight hash was invented.

Simulation QA remains held until a nonblocking same-SHA audit and explicit source-parent release; this BLOCK does not qualify. Provider-cancellation diagnosis and Claude owner acknowledgement remain unresolved. No live models, real credentials/user data, native effects, outbound communications, training, activation, installed-app replacement, deployment, publishing or merges were performed. Wisp 1.3.0 and the user's no-merge instruction remain binding.

`REPORT.json` records full structured evidence, `HANDOFF.json` records the disposition, and `CHECKSUMS.json` recursively seals output bytes (including synthetic fixtures and failures). Symlink targets are hashed without dereferencing. Recorded UTC: {now}.
'''
(OUT / 'REPORT.md').write_text(md)
handoff = {
    'candidate_sha': SHA, 'base_sha': BASE, 'verdict': 'BLOCK', 'pr_url': report['pr_url'],
    'target_version': '1.3.0', 'merge_authorized': False, 'source_changed_by_auditor': False,
    'outcome': 'Full same-SHA independent audit complete; P1 R11 streaming isolation bypass blocks candidate despite passing exact-head local/Python/artifact CI.',
    'findings': [{'id': 'R11', 'priority': 'P1', 'disposition': 'BLOCK', 'artifact': 'R11_FINDING.json', 'sha256': report['bounded_finding_sha256']}],
    'prior_r10': r10['disposition'], 'ci': ci, 'verification': report['verification'], 'provenance': report['provenance'],
    'report': {'markdown': 'REPORT.md', 'markdown_sha256': digest(OUT / 'REPORT.md'), 'json': 'REPORT.json', 'json_sha256': digest(OUT / 'REPORT.json')},
    'limitations_and_holds': limits, 'required_next_step': report['required_repair'],
    'integration_dependency': 'Existing source parent is sole dispatcher/integrator; Orchestrator sole-owner acknowledgement is required before any repair. Any new SHA invalidates existing gates and requires a fresh exact-SHA audit and held specialist QA release.',
    'recorded_at_utc': now,
}
write('HANDOFF.json', handoff)
print(json.dumps({'candidate_sha': SHA, 'verdict': 'BLOCK', 'report_sha256': digest(OUT / 'REPORT.md'), 'handoff_sha256': digest(OUT / 'HANDOFF.json'), 'provenance': '1473/1473', 'ci': 'local/Python/artifact PASS; publish skipped'}))
