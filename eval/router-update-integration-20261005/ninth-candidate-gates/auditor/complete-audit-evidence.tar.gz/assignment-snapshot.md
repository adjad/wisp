# Exact gate assignment: Wisp router 1.3

Candidate `67e4cefa53687f265287b9d068fc549c1f7955b6`; base `4994caa15533c0cf84c07208c9097e4197f2815b`; clean branch `codex/router-update-1-3`; existing draft [PR160](https://github.com/adjad/wisp/pull/160). Local, actual remote and PR heads match. Recorded 2026-10-06T03:14:18.340972+00:00.

Source parent **Reevaluate tool call routing** (`01a10aef-17bd-7f80-b5c8-f5cc08fe2506`) is the sole dispatcher/integrator. All source writers stay frozen. Root coordinates and verifies receipts only.

## Direct human authorization

User message `01a10f2f-296f-74b3-88cb-cace927e70ca` in turn `01a10f2f-2836-7b72-a300-ffbe083a9bb2` says “ok go ahead” in direct response to the pending checksum-only question and held-gate explanation. This permits the unchanged SHA256-only integrity test, full validation and non-force existing PR push. No heldout prompt parsing/display/evaluation/tuning, live model/native/private-data/outbound work, training or shipping is authorized. Old task automations remain paused.

The admitted checksum test passed at `c456363`: one pass and one configuration warning in0.06s. Its raw log is preserved losslessly; the prior rejection remains intact. Owned approval/evidence documentation then produced final `67e4cef`, with no further source changes. No earlier pass transfers to this final SHA.

## Independent Release Auditor

Use existing **Wisp Release Auditor**, `01a08523-47c7-76e3-be42-aee801a314fd`, GPT-6.1 Sol/high. Obtain fresh exact-SHA acceptance. Review full intended449-path diff from main and96-path delta since44babb7, all prior findings/provenance and retained routing/overview contracts.

Focus on R10: seven existing negation guards and three existing reminder selectors using the existing quote mask, preserving literal bytes, offsets, patterns, order and grammar. Test genuine outside instructions, unmatched quotes, contractions/possessives, source exclusions/later effects and truthful fake readback; retain unsupported Check off syntax disclosure.

Review evaluation capability default denial, exact target projection/auth delegation, real transport authority boundaries, genuine fixture quarantine/lock pinning/races/lease, strict path/origin/model/request/argv limits, context propagation, real-clock expiry/revocation and truthful cancellation/cleanup. Keep the original grant contract, corpus/gold/scorer and provenance claims. Offline fixtures and MockTransport do not establish actual runtime readiness.

Read-only source; synthetic verification only; output `/private/tmp/wisp-router-67e4cef-gates-20261005/auditor/`. Preserve commands, all failures/corrections and raw results, and seal a same-SHA PASS/PASS_WITH_NOTES/BLOCK verdict. No live clients/network/model/native/user-data/outbound actions or production auth reads. Only the unchanged checksum test may hash sealed bytes without reading prompts semantically.

## Distinct Simulation QA

Use existing **Wisp Simulation QA**, `01a08531-b393-7690-a072-5776c3cbed4c`, GPT-6.1 Sol/high. Fresh scope/availability acceptance may be requested now. Execution stays held until formal nonblocking same-SHA audit and explicit source-parent release.

Cover inherited synthetic application/source/privacy/action/task/overview/error behavior, quoted-title boundaries and offline capability isolation/auth/default-denial/expiry/cancellation/cleanup. All registered effects and dependencies must be inert fakes in isolated state. Output `/private/tmp/wisp-router-67e4cef-gates-20261005/simulation-qa/`; seal SIM_PASS/NOTES/FAIL at this SHA. No real model/native/credentials/private data/effects. Builder, auditor and QA remain distinct.

## Required gates and remaining decisions

The parent already started one full final-SHA local regression, session59235, raw `/private/tmp/wisp-router-update-67e4cef-regression.log`; do not launch a duplicate. Completion receipt and required Python/artifact CI results remain pending. Verify all final exact-SHA receipts; no previous local/CI/audit/QA approval transfers. Any newSHA requires a new scope ACK and fresh gates. No publishing jobs are authorized.

Builder scriptedDEV remains integration evidence:80/80 source/arguments,48/48 first call,72/80 original end-to-end,16/16 applicable failure honesty. Eight annotation limitations, correlated variants and zero-applicable metric denominators remain disclosed. It is not model accuracy or training uplift.

Real resident-model evaluation still needs separate current identity/readiness/provenance, valid exclusive resource window, same-SHA independent auth audit/QA and fresh runtime admission. No invented loaded-weight hash/binding. Provider/native/performance ownership remains withClaude; training/provider diagnosis stay unresolved. No feature activation, merge, deployment or release approval is implied.
