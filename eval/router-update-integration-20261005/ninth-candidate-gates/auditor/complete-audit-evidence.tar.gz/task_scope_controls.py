import sys,json,tempfile,traceback
from pathlib import Path
from datetime import datetime
ROOT=Path('/Users/adijain/.codex/worktrees/router-update-integration/MOE_Project');OUT=Path('/private/tmp/wisp-router-67e4cef-gates-20261005/auditor')
sys.path.insert(0,str(ROOT));from scripts import eval_router_update as e
SHA=e.git_revision();assert SHA=='67e4cefa53687f265287b9d068fc549c1f7955b6'
state=Path(tempfile.mkdtemp(prefix='wisp-67e4cef-task-scope-'));e.install_guard(state,OUT)
from service.tasks import compiler as T
now=datetime(2026,10,5,12);rows=[]
def test(n,p,f,expected):
 r=dict(id=n,prompt=p)
 try:
  result=f(p,now=now);r['plan']=None if result is None else result.to_dict();assert result is not None and result.intent==expected,(p,result);r['pass']=True
 except Exception as ex:r.update(pass_=False,error=repr(ex),trace=traceback.format_exc());r['pass']=False
 rows.append(r)
test('delete-literal','Delete reminder called "Ledger: don’t complete this item"',T.compile_reminder_delete,'reminder.delete')
test('complete-literal','Complete reminder called "Ledger: don’t delete this item"',T.compile_reminder_complete,'reminder.complete')
test('update-literal','Move reminder called "Ledger: don’t complete this item" to tomorrow afternoon',T.compile_reminder_update,'reminder.update')
test('create-literal','Remind me tomorrow night to say "don’t send this item"',T.compile_reminder_create,'reminder.create')
test('message-literal','Text Avery saying "don’t send this item"',T.compile_message_send,'message.send')
test('email-literal','Email Avery about Ledger saying "don’t send this item"',T.compile_email_send,'email.send')
test('reply-literal','Reply to that email saying "don’t send this item"',T.compile_email_reply,'email.reply')
# Record deliberately explored quoting shapes as pre-existing syntax limitations.
observations=[]
for p in ['Complete reminder called “Ledger entry”',"Complete reminder called 'Ledger: don't check this item'"]:
 plan=T.compile_task(p,now=now);observations.append(dict(prompt=p,mask=T._unquoted(p),plan=None if plan is None else plan.to_dict()))
(OUT/'task-scope-results.json').write_text(json.dumps(dict(candidate_sha=SHA,passed=sum(r['pass'] for r in rows),total=len(rows),rows=rows,exploratory_grammar_observations=observations,basis='The delta only changes guard/selectors to the pre-existing _unquoted helper; _unquoted/_operation_target/_clean_target and quoting grammar are unchanged. Curly-quoted title extraction retains delimiters even for a plain non-negative name; nested ASCII apostrophe in single quotes shares the existing mask behavior. The 18 primary exploratory failures are retained and not credited as passes or new R10 regressions.'),indent=2,ensure_ascii=False));print(json.dumps(dict(passed=sum(r['pass'] for r in rows),total=len(rows),failures=[dict(id=r['id'],error=r.get('error')) for r in rows if not r['pass']])))
